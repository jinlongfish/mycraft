import cv2  # 导入OpenCV库，用于图像处理

# 以灰度模式读取图片，cv2.IMREAD_GRAYSCALE表示直接读取为灰度图
gray = cv2.imread("opencv_logo.jpg", cv2.IMREAD_GRAYSCALE)

# 使用拉普拉斯算子检测边缘
# 参数：(输入图像, 输出图像深度, ksize=1)
# cv2.CV_64F: 使用64位浮点精度，能够保留边缘的正负变化
laplacian = cv2.Laplacian(gray, cv2.CV_64F)

# 使用Canny边缘检测算法
# 参数：(输入图像, 低阈值, 高阈值)
# 低于低阈值的边缘被舍弃，高于高阈值的保留为强边缘
canny = cv2.Canny(gray, 100, 200)

# 显示原图（灰度图）
cv2.imshow('gray', gray)

# 显示拉普拉斯边缘检测结果
cv2.imshow('laplacian', laplacian)

# 显示Canny边缘检测结果
cv2.imshow('canny', canny)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()