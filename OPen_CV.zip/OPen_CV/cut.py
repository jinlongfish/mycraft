import cv2  # 导入OpenCV库，用于图像处理

# 读取图片文件，返回一个numpy数组
image = cv2.imread('opencv_logo.jpg')

# 裁剪图片：数组切片语法 [行_start:行_end, 列_start:列_end]
# 从原图第10~170行、第40~200列的区域进行裁剪
crop = image[10:170, 40:200]

# 在窗口中显示裁剪后的图像，窗口标题为'crop'
cv2.imshow('crop', crop)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()