import cv2  # 导入OpenCV库，用于图像处理
import numpy as np  # 导入NumPy库，用于数组操作

# 以灰度模式读取图片
gray = cv2.imread('opencv_logo.jpg', cv2.IMREAD_GRAYSCALE)

# 反二值化处理：大于阈值(200)设为0，小于等于阈值设为最大值(255)
# THRESH_BINARY_INV: 反向二值化，背景变黑，前景变白
ret, binary = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)

# 创建5x5的结构元素（核），用于形态学操作
# np.ones((5,5), np.uint8) 创建全1数组，uint8类型
kernel = np.ones((5, 5), np.uint8)

# 腐蚀操作：缩小前景区域，用于去除小噪声点或分离相邻物体
erosion = cv2.erode(binary, kernel)

# 膨胀操作：扩大前景区域，用于填充空洞或连接断裂的物体
dilation = cv2.dilate(binary, kernel)

# 显示二值化后的图像
cv2.imshow('binary', binary)

# 显示腐蚀后的图像
cv2.imshow('erosion', erosion)

# 显示膨胀后的图像
cv2.imshow('dilation', dilation)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()