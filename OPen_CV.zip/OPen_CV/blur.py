import cv2  # 导入OpenCV库，用于图像处理

# 读取图片文件，返回一个numpy数组
image = cv2.imread('plane.jpg')

# 中值滤波：参数依次为(输入图像, 核大小)，用于去除椒盐噪声
mblur = cv2.medianBlur(image, 5)

# 高斯模糊：参数依次为(输入图像, 核大小(宽,高), 标准差)，用于平滑图像
gauss = cv2.GaussianBlur(image, (5, 5), 0)

# 显示原图
cv2.imshow('image', image)

# 显示高斯模糊后的图像
cv2.imshow('gauss', gauss)

# 显示中值滤波后的图像
cv2.imshow('mblur', mblur)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()