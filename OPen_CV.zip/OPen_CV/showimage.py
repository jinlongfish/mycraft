import cv2  # 导入OpenCV库，用于图像处理

# 打印OpenCV版本信息
print(cv2.getVersionString())

# 读取图片文件，返回一个numpy数组
image = cv2.imread('opencv_logo.jpg')

# 打印图片的形状信息：(高度, 宽度, 通道数)
print(image.shape)

# 在窗口中显示原图，窗口标题为'image'
cv2.imshow('image', image)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()
