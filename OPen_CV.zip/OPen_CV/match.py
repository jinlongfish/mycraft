import cv2  # 导入OpenCV库，用于图像处理
import numpy as np  # 导入NumPy库，用于数组操作

# 读取图片文件，返回一个numpy数组
image = cv2.imread("poker.jpg")

# 将彩色图转换为灰度图，模板匹配通常在灰度图上进行
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 从灰度图中裁剪出模板区域（作为要匹配的目标）
# 语法：[y_start:y_end, x_start:x_end]
template = gray[75:105, 235:265]

# 使用模板匹配算法在原图中搜索模板
# 参数：(原图, 模板, 匹配方法)
# TM_CCOEFF_NORMED: 归一化相关系数匹配，结果范围[-1, 1]，越接近1匹配度越高
match = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)

# 筛选匹配度大于等于0.9的位置
locations = np.where(match >= 0.9)

# 获取模板的宽度和高度
w, h = template.shape[0:2]

# 遍历所有匹配位置，绘制矩形框
# locations[::-1] 将(y,x)坐标转换为(x,y)格式
for p in zip(*locations[::-1]):
    x1, y1 = p[0], p[1]  # 左上角坐标
    x2, y2 = x1 + w, y1 + h  # 右下角坐标
    # 在原图上绘制黄色矩形框标记匹配区域
    cv2.rectangle(image, (x1, y1), (x2, y2), (255, 255, 0), 1)

# 显示匹配结果图像
cv2.imshow('template', image)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()