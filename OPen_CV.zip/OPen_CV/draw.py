import cv2  # 导入OpenCV库，用于图像处理
import numpy as np  # 导入NumPy库，用于数组操作

# 创建一个300x300的黑色图像，3通道(BGR)，数据类型为uint8
image = np.zeros([300, 300, 3], dtype=np.uint8)

# 画直线：参数依次为(图像, 起点, 终点, 颜色BGR, 线宽)
cv2.line(image, (23, 34), (56, 78), (0, 255, 0), 4)

# 画矩形：参数依次为(图像, 左上角, 右下角, 颜色BGR, 线宽)
cv2.rectangle(image, (56, 78), (89, 111), (0, 0, 255), 7)

# 画圆：参数依次为(图像, 圆心坐标, 半径, 颜色BGR, 线宽)
cv2.circle(image, (100, 100), 30, (255, 0, 0), 5)

# 添加文字：参数依次为(图像, 文字内容, 左下角坐标, 字体类型, 字体大小, 颜色BGR, 线宽, 线型)
cv2.putText(image, 'HELLO', (100, 222), 0, 1, (255, 255, 255), 2, 1)

# 在窗口中显示绘制后的图像，窗口标题为'image'
cv2.imshow('image', image)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()