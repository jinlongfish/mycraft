import cv2  # 导入OpenCV库，用于图像处理

# 打开默认摄像头（参数0表示第一个摄像头设备）
# 返回VideoCapture对象，用于读取摄像头帧
capture = cv2.VideoCapture(0)

# 无限循环，持续读取并显示摄像头画面
while True:
    # 从摄像头读取一帧图像
    # ret: 读取是否成功（True/False）
    # frame: 读取到的图像帧
    ret, frame = capture.read()

    # 在窗口中显示当前帧，窗口标题为'camera'
    cv2.imshow('camera', frame)

    # 等待1毫秒，读取键盘输入
    # waitKey(1) 返回按键的ASCII码，无按键则返回-1
    key = cv2.waitKey(1)
    if key != -1:  # 如果有任意按键按下，退出循环
        break

# 释放摄像头资源，重要！否则摄像头会被占用
capture.release()