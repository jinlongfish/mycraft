import cv2  # 导入OpenCV库，用于图像处理

# 读取图片文件，返回一个numpy数组
image = cv2.imread("opencv_logo.jpg")

# 将彩色图转换为灰度图，角点检测需要灰度图作为输入
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 使用Shi-Tomasi角点检测算法检测关键点
# 参数：(输入图像, 最大检测点数, 质量等级, 最小距离)
keypoint = cv2.goodFeaturesToTrack(gray, 500, 0.1, 10)

# 遍历每个检测到的关键点
for i in keypoint:
    x, y = i.ravel()  # 将数组展平为一维
    # 在关键点位置绘制红色实心圆
    # 参数：(图像, 圆心坐标, 半径, 颜色BGR, 线条粗细(-1表示填充))
    cv2.circle(image, (int(x), int(y)), 3, (0, 0, 255), -1)

# 在窗口中显示带有关键点标记的图像
cv2.imshow('image', image)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()