import cv2  # 导入OpenCV库，用于图像处理

# 以灰度模式读取图片，cv2.IMREAD_GRAYSCALE表示直接读取为灰度图
gray = cv2.imread('bookpage.jpg', cv2.IMREAD_GRAYSCALE)

# 简单阈值处理：全局使用同一个阈值
# 参数：(输入图像, 阈值, 最大值, 阈值类型)
# THRESH_BINARY: 大于阈值设为最大值(255)，小于等于阈值设为0
ret, binary = cv2.threshold(gray, 10,255,  cv2.THRESH_BINARY)

# 自适应阈值处理：根据局部区域计算阈值
# 参数：(输入图像, 最大值, 自适应方法, 阈值类型, 块大小, 常数)
# ADAPTIVE_THRESH_GAUSSIAN_C: 使用高斯加权平均计算局部阈值
binary_adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 115, 1)

# Otsu阈值处理：自动计算最佳阈值
# 参数：(输入图像, 阈值(设为0), 最大值, 阈值类型+OTSU标志)
# THRESH_OTSU: 自动分析图像直方图，找到最佳分割阈值（ret1不用也可以，是 Otsu 算法自动计算出的 最佳分割阈值）
ret1, binary_otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# 显示原图（灰度图）
cv2.imshow('gray', gray)

# 显示简单阈值处理结果
cv2.imshow('maxs', binary)

# 显示自适应阈值处理结果
cv2.imshow('binary_adptive', binary_adaptive)

# 显示Otsu阈值处理结果
cv2.imshow('binary_adptive_otsu', binary_otsu)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()