import cv2  # 导入OpenCV库，用于图像处理

# 读取图片文件，返回一个numpy数组
image = cv2.imread('opencv_logo.jpg')

# 显示蓝色通道：OpenCV使用BGR格式，索引0表示蓝色通道
cv2.imshow('blue', image[:, :, 0])

# 显示绿色通道：索引1表示绿色通道
cv2.imshow('green', image[:, :, 1])

# 显示红色通道：索引2表示红色通道
cv2.imshow('red', image[:, :, 2])

# 将图片从BGR颜色空间转换为灰度图
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 显示灰度图
cv2.imshow('gray', gray)

# 等待按键事件，参数0表示无限等待直到按键触发
cv2.waitKey(0)

# 关闭所有OpenCV创建的窗口，释放资源
cv2.destroyAllWindows()
